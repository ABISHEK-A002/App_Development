import React from 'react';
import '../Assets/Styles/CustomCarAnimation.css';

const CustomCarAnimation = () => {
    return (
        <div className="custom-html">
            <div className="custom-body"></div>
        </div>
    );
}

export default CustomCarAnimation;
