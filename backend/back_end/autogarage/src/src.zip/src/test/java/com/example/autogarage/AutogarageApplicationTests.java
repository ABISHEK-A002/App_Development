package com.example.autogarage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutogarageApplicationTests {

	@Test
	void contextLoads() {
	}

}
