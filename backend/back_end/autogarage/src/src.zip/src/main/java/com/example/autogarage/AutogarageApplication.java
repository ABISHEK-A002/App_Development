package com.example.autogarage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutogarageApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutogarageApplication.class, args);
	}

}
